package com.example.procam

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.hardware.camera2.CameraCharacteristics as CC
import android.hardware.camera2.CaptureRequest as CR
import android.util.Size
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class ShootMode { AUTO, DETAIL, NIGHT, HDR }

class CameraEngine(private val ctx: Context) {
    private var provider: ProcessCameraProvider? = null
    private var extMgr: ExtensionsManager? = null
    private var capture: ImageCapture? = null
    var camera: Camera? = null; private set
    private val executor = Executors.newSingleThreadExecutor()

    suspend fun bind(owner: LifecycleOwner, view: PreviewView, mode: ShootMode, flash: Int) {
        val p = provider ?: ProcessCameraProvider.getInstance(ctx).await().also { provider = it }
        val em = extMgr ?: ExtensionsManager.getInstanceAsync(ctx, p).await().also { extMgr = it }
        val base = CameraSelector.DEFAULT_BACK_CAMERA

        // Characteristics of the back camera, to enable only supported quality options.
        val info = base.filter(p.availableCameraInfos).firstOrNull()?.let { Camera2CameraInfo.from(it) }
        fun modes(key: CC.Key<IntArray>): IntArray = info?.getCameraCharacteristic(key) ?: IntArray(0)

        var selector = base
        var usingExt = false
        val extMode = when (mode) { ShootMode.NIGHT -> ExtensionMode.NIGHT; ShootMode.HDR -> ExtensionMode.HDR; else -> ExtensionMode.NONE }
        if (extMode != ExtensionMode.NONE && em.isExtensionAvailable(base, extMode)) {
            selector = em.getExtensionEnabledCameraSelector(base, extMode); usingExt = true
        }

        val ratio = AspectRatioStrategy(AspectRatioStrategy.RATIO_4_3, AspectRatioStrategy.FALLBACK_RULE_AUTO)
        val capSel = ResolutionSelector.Builder()
            .setAspectRatioStrategy(ratio)
            .setAllowedResolutionMode(ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE)
            .setResolutionStrategy(
                if (mode == ShootMode.DETAIL) // ~16MP per frame so burst stacking fits in memory
                    ResolutionStrategy(Size(4608, 3456), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
                else ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY
            ).build()

        val icb = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setJpegQuality(100)
            .setResolutionSelector(capSel)
            .setFlashMode(flash)

        if (!usingExt) {
            val x = Camera2Interop.Extender(icb)
            if (CR.NOISE_REDUCTION_MODE_HIGH_QUALITY in modes(CC.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES))
                x.setCaptureRequestOption(CR.NOISE_REDUCTION_MODE, CR.NOISE_REDUCTION_MODE_HIGH_QUALITY)
            if (CR.EDGE_MODE_HIGH_QUALITY in modes(CC.EDGE_AVAILABLE_EDGE_MODES))
                x.setCaptureRequestOption(CR.EDGE_MODE, CR.EDGE_MODE_HIGH_QUALITY)
            if (CR.HOT_PIXEL_MODE_HIGH_QUALITY in modes(CC.HOT_PIXEL_AVAILABLE_HOT_PIXEL_MODES))
                x.setCaptureRequestOption(CR.HOT_PIXEL_MODE, CR.HOT_PIXEL_MODE_HIGH_QUALITY)
            if (CR.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY in modes(CC.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES))
                x.setCaptureRequestOption(CR.COLOR_CORRECTION_ABERRATION_MODE, CR.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY)
            if (CR.LENS_OPTICAL_STABILIZATION_MODE_ON in modes(CC.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION))
                x.setCaptureRequestOption(CR.LENS_OPTICAL_STABILIZATION_MODE, CR.LENS_OPTICAL_STABILIZATION_MODE_ON)
            if (CR.SHADING_MODE_HIGH_QUALITY in modes(CC.SHADING_AVAILABLE_MODES))
                x.setCaptureRequestOption(CR.SHADING_MODE, CR.SHADING_MODE_HIGH_QUALITY)
            if (CR.DISTORTION_CORRECTION_MODE_HIGH_QUALITY in modes(CC.DISTORTION_CORRECTION_AVAILABLE_MODES))
                x.setCaptureRequestOption(CR.DISTORTION_CORRECTION_MODE, CR.DISTORTION_CORRECTION_MODE_HIGH_QUALITY)
        }

        val preview = Preview.Builder()
            .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(ratio).build())
            .build().also { it.surfaceProvider = view.surfaceProvider }

        capture = icb.build()
        p.unbindAll()
        camera = p.bindToLifecycle(owner, selector, preview, capture!!)
    }

    fun zoomRange(): Pair<Float, Float> {
        val z = camera?.cameraInfo?.zoomState?.value ?: return 1f to 1f
        return z.minZoomRatio to z.maxZoomRatio
    }
    fun currentZoom(): Float = camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: 1f
    fun setZoom(r: Float) { camera?.cameraControl?.setZoomRatio(r) }
    fun setTorch(on: Boolean) { camera?.cameraControl?.enableTorch(on) }
    fun setFlash(mode: Int) { capture?.flashMode = mode }

    fun evRange(): Pair<Int, Int> {
        val r = camera?.cameraInfo?.exposureState?.exposureCompensationRange ?: return 0 to 0
        return r.lower to r.upper
    }
    fun setEv(i: Int) { camera?.cameraControl?.setExposureCompensationIndex(i) }

    fun focus(view: PreviewView, x: Float, y: Float) {
        val pt = view.meteringPointFactory.createPoint(x, y)
        camera?.cameraControl?.startFocusAndMetering(
            FocusMeteringAction.Builder(pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE or FocusMeteringAction.FLAG_AWB)
                .build()
        )
    }

    suspend fun grab(): Bitmap = suspendCancellableCoroutine { c ->
        val cap = capture ?: run { c.resumeWithException(IllegalStateException("camera not ready")); return@suspendCancellableCoroutine }
        cap.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val b = image.toBitmap()
                    val deg = image.imageInfo.rotationDegrees
                    val out = if (deg != 0) Bitmap.createBitmap(b, 0, 0, b.width, b.height,
                        Matrix().apply { postRotate(deg.toFloat()) }, true).also { b.recycle() } else b
                    c.resume(out)
                } catch (e: Throwable) { c.resumeWithException(e) } finally { image.close() }
            }
            override fun onError(e: ImageCaptureException) { c.resumeWithException(e) }
        })
    }
}
