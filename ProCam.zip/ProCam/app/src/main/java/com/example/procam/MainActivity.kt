package com.example.procam

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.ImageCapture
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import org.opencv.android.OpenCVLoader
import kotlin.math.roundToInt

private val Accent = Color(0xFFFFC107)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        OpenCVLoader.initLocal()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Root() } }
    }
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }
    if (granted) CameraScreen() else Box(Modifier.fillMaxSize().background(Color.Black), Alignment.Center) {
        Text("Camera permission required", color = Color.White)
    }
}

@Composable
fun CameraScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val engine = remember { CameraEngine(ctx) }
    val previewView = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FIT_CENTER } }

    var mode by remember { mutableStateOf(ShootMode.DETAIL) }
    val flashModes = listOf(ImageCapture.FLASH_MODE_OFF, ImageCapture.FLASH_MODE_AUTO, ImageCapture.FLASH_MODE_ON)
    var flashIdx by remember { mutableIntStateOf(0) }
    var torch by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var zmin by remember { mutableFloatStateOf(1f) }
    var zmax by remember { mutableFloatStateOf(1f) }
    var ev by remember { mutableFloatStateOf(0f) }
    var evRange by remember { mutableStateOf(0 to 0) }
    var busy by remember { mutableStateOf<String?>(null) }
    var thumb by remember { mutableStateOf<Bitmap?>(null) }
    var focusPt by remember { mutableStateOf<Offset?>(null) }
    var grid by remember { mutableStateOf(true) }

    LaunchedEffect(mode) {
        engine.bind(owner, previewView, mode, flashModes[flashIdx])
        engine.zoomRange().let { zmin = it.first; zmax = it.second }
        zoom = engine.currentZoom(); evRange = engine.evRange(); ev = 0f
    }
    LaunchedEffect(focusPt) { if (focusPt != null) { delay(1200); focusPt = null } }

    fun shoot() {
        if (busy != null) return
        scope.launch {
            try {
                val z = engine.currentZoom()
                val frames = when {
                    mode == ShootMode.DETAIL && flashModes[flashIdx] != ImageCapture.FLASH_MODE_ON -> if (z >= 3f) 8 else 6
                    else -> 1
                }
                val stacker = Stacker()
                for (i in 1..frames) {
                    busy = if (frames > 1) "Capturing $i/$frames" else "Capturing"
                    val b = engine.grab()
                    withContext(Dispatchers.Default) { stacker.add(b) }
                }
                busy = "Enhancing…"
                val out = withContext(Dispatchers.Default) {
                    Enhancer.enhance(stacker.finish(), z, frames, mode == ShootMode.NIGHT)
                }
                withContext(Dispatchers.IO) { Enhancer.save(ctx, out) }
                thumb = Bitmap.createScaledBitmap(out, 160, 160 * out.height / out.width, true)
                out.recycle()
            } catch (e: Throwable) { e.printStackTrace() }
            busy = null
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ previewView }, Modifier.fillMaxSize().padding(top = 72.dp, bottom = 230.dp))

        // Gestures overlay: pinch to zoom, tap to focus
        Box(Modifier.fillMaxSize().padding(top = 72.dp, bottom = 230.dp)
            .pointerInput(Unit) {
                detectTransformGestures { _, _, g, _ ->
                    zoom = (zoom * g).coerceIn(zmin, zmax); engine.setZoom(zoom)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { o -> focusPt = o; engine.focus(previewView, o.x, o.y) }
            }) {
            if (grid) Canvas3x3()
            focusPt?.let { p ->
                Box(Modifier.offset { androidx.compose.ui.unit.IntOffset((p.x - 36.dp.toPx()).roundToInt(), (p.y - 36.dp.toPx()).roundToInt()) }
                    .size(72.dp).border(1.5.dp, Accent, RoundedCornerShape(8.dp)))
            }
            Text("${"%.1f".format(zoom)}x", color = Accent, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp)
                    .background(Color(0x66000000), RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 4.dp))
        }

        // Top bar
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp).height(56.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            RoundBtn(when (flashIdx) { 0 -> Icons.Default.FlashOff; 1 -> Icons.Default.FlashAuto; else -> Icons.Default.FlashOn }, flashIdx != 0) {
                flashIdx = (flashIdx + 1) % 3; engine.setFlash(flashModes[flashIdx])
            }
            RoundBtn(Icons.Default.FlashlightOn, torch) { torch = !torch; engine.setTorch(torch) }
            RoundBtn(Icons.Default.GridOn, grid) { grid = !grid }
        }

        // Bottom controls
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(bottom = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            // Zoom chips
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val stops = (listOf(zmin) + listOf(1f, 2f, 5f, 10f, 20f)).filter { it in zmin..zmax }.distinct()
                stops.forEach { s ->
                    val sel = kotlin.math.abs(zoom - s) < 0.15f
                    Text(if (s < 1f) "%.1f".format(s) else "${s.toInt()}x", color = if (sel) Color.Black else Color.White, fontSize = 13.sp,
                        modifier = Modifier.clip(CircleShape).background(if (sel) Accent else Color(0x55FFFFFF))
                            .clickable { zoom = s; engine.setZoom(s) }.padding(horizontal = 12.dp, vertical = 6.dp))
                }
            }
            if (zmax > zmin) Slider(zoom, { zoom = it; engine.setZoom(it) }, valueRange = zmin..zmax,
                modifier = Modifier.padding(horizontal = 32.dp), colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
            if (evRange.second > 0) Row(Modifier.padding(horizontal = 32.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.WbSunny, null, tint = Color.White, modifier = Modifier.size(18.dp))
                Slider(ev, { ev = it; engine.setEv(it.roundToInt()) }, valueRange = evRange.first.toFloat()..evRange.second.toFloat(),
                    modifier = Modifier.weight(1f).padding(start = 8.dp), colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White))
            }
            // Mode selector
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                ShootMode.values().forEach { m ->
                    Text(m.name, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = if (m == mode) Accent else Color.LightGray,
                        modifier = Modifier.clickable { mode = m })
                }
            }
            // Thumbnail + shutter
            Row(Modifier.fillMaxWidth().padding(horizontal = 36.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF222222))) {
                    thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                }
                Box(Modifier.size(78.dp).border(4.dp, Color.White, CircleShape).padding(7.dp)
                    .clip(CircleShape).background(if (busy == null) Color.White else Color.Gray).clickable { shoot() })
                Spacer(Modifier.size(52.dp))
            }
        }

        busy?.let {
            Box(Modifier.fillMaxSize().background(Color(0x99000000)), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Accent); Spacer(Modifier.height(12.dp)); Text(it, color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun RoundBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(42.dp).clip(CircleShape).background(if (active) Accent else Color(0x55FFFFFF)).clickable { onClick() }, Alignment.Center) {
        Icon(icon, null, tint = if (active) Color.Black else Color.White)
    }
}

@Composable
private fun Canvas3x3() {
    androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
        val c = Color(0x44FFFFFF)
        for (i in 1..2) {
            drawLine(c, Offset(size.width * i / 3, 0f), Offset(size.width * i / 3, size.height), 1f)
            drawLine(c, Offset(0f, size.height * i / 3), Offset(size.width, size.height * i / 3), 1f)
        }
    }
}
