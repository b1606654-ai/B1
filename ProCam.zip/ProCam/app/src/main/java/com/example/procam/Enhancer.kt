package com.example.procam

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.provider.MediaStore
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.CLAHE
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import org.opencv.video.Video
import kotlin.math.min

/** Multi-frame stacking: align (ECC) + ghost-rejecting average => less noise, more real detail. */
class Stacker {
    private var ref: Mat? = null
    private var refSmall: Mat? = null
    private var refBlur: Mat? = null
    private var acc: Mat? = null
    private var wsum: Mat? = null
    var count = 0; private set
    private val s = 0.25

    private fun gray(m: Mat) = Mat().also { Imgproc.cvtColor(m, it, Imgproc.COLOR_BGR2GRAY) }

    fun add(bmp: Bitmap) {
        val rgba = Mat(); Utils.bitmapToMat(bmp, rgba); bmp.recycle()
        val m = Mat(); Imgproc.cvtColor(rgba, m, Imgproc.COLOR_RGBA2BGR); rgba.release()
        if (ref == null) {
            ref = m
            val g = gray(m)
            refSmall = Mat().also { Imgproc.resize(g, it, Size(), s, s, Imgproc.INTER_AREA) }
            refBlur = Mat().also { Imgproc.GaussianBlur(g, it, Size(7.0, 7.0), 0.0) }
            g.release()
            acc = Mat().also { m.convertTo(it, CvType.CV_32FC3) }
            wsum = Mat(m.size(), CvType.CV_32FC1, Scalar(1.0))
        } else {
            val a = align(m); m.release()
            val g = gray(a)
            val gb = Mat(); Imgproc.GaussianBlur(g, gb, Size(7.0, 7.0), 0.0); g.release()
            val d = Mat(); Core.absdiff(gb, refBlur, d); gb.release()
            val mask8 = Mat(); Imgproc.threshold(d, mask8, 20.0, 1.0, Imgproc.THRESH_BINARY_INV); d.release()
            val mf = Mat(); mask8.convertTo(mf, CvType.CV_32F); mask8.release()
            val mf3 = Mat(); Imgproc.cvtColor(mf, mf3, Imgproc.COLOR_GRAY2BGR)
            val af = Mat(); a.convertTo(af, CvType.CV_32FC3); a.release()
            Core.multiply(af, mf3, af)
            Core.add(acc, af, acc); Core.add(wsum, mf, wsum)
            af.release(); mf3.release(); mf.release()
        }
        count++
    }

    private fun align(frame: Mat): Mat {
        val g = gray(frame)
        val small = Mat(); Imgproc.resize(g, small, Size(), s, s, Imgproc.INTER_AREA); g.release()
        val warp = Mat.eye(2, 3, CvType.CV_32F)
        try {
            Video.findTransformECC(refSmall, small, warp, Video.MOTION_EUCLIDEAN,
                TermCriteria(TermCriteria.COUNT + TermCriteria.EPS, 40, 1e-4), Mat(), 5)
        } catch (e: CvException) { small.release(); return frame.clone() }
        small.release()
        warp.put(0, 2, warp.get(0, 2)[0] / s); warp.put(1, 2, warp.get(1, 2)[0] / s)
        val out = Mat()
        Imgproc.warpAffine(frame, out, warp, frame.size(),
            Imgproc.INTER_LINEAR + Imgproc.WARP_INVERSE_MAP, Core.BORDER_REPLICATE)
        return out
    }

    fun finish(): Mat {
        val w3 = Mat(); Imgproc.cvtColor(wsum, w3, Imgproc.COLOR_GRAY2BGR)
        Core.divide(acc, w3, acc)
        val out = Mat(); acc!!.convertTo(out, CvType.CV_8UC3)
        w3.release(); acc!!.release(); wsum!!.release(); ref!!.release(); refSmall!!.release(); refBlur!!.release()
        return out
    }
}

object Enhancer {
    /** Full post-capture pipeline. [img] is BGR 8U; modified and returned. */
    fun enhance(img: Mat, zoom: Float, frames: Int, night: Boolean): Bitmap {
        val z = min(zoom, 10f).toDouble()
        // 1) Atmospheric-haze removal (dark channel prior) - helps distant subjects
        if (z >= 2.0) dehaze(img, 0.6 + 0.04 * z)

        // 2) Luminance/chroma separation
        val ycc = Mat(); Imgproc.cvtColor(img, ycc, Imgproc.COLOR_BGR2YCrCb)
        val ch = ArrayList<Mat>(); Core.split(ycc, ch); ycc.release()
        val y = ch[0]

        // 3) Denoise: strong on chroma, adaptive non-local-means on luma (less if already stacked)
        Imgproc.GaussianBlur(ch[1], ch[1], Size(0.0, 0.0), if (night) 3.0 else 1.5)
        Imgproc.GaussianBlur(ch[2], ch[2], Size(0.0, 0.0), if (night) 3.0 else 1.5)
        val h = (if (frames > 1) 2.0 else 4.0) + (if (night) 3.0 else 0.0) + 0.2 * z
        Photo.fastNlMeansDenoising(y, y, h.toFloat(), 5, 15)

        // 4) Local contrast (CLAHE) on luma
        val clahe: CLAHE = Imgproc.createCLAHE(if (night) 3.0 else 2.0, Size(8.0, 8.0))
        clahe.apply(y, y)

        // 5) Multi-scale unsharp mask: fine detail + mid-scale "clarity"; stronger with zoom
        unsharp(y, 0.6 + 0.12 * z, 1.1)
        unsharp(y, 0.25, 25.0)

        // 6) Gentle S-curve for depth
        val lut = Mat(1, 256, CvType.CV_8UC1)
        for (i in 0..255) {
            val v = i / 255.0; val sm = v * v * (3 - 2 * v)
            lut.put(0, i, byteArrayOf((255 * (0.85 * v + 0.15 * sm)).toInt().coerceIn(0, 255).toByte()))
        }
        Core.LUT(y, lut, y); lut.release()

        val merged = Mat(); Core.merge(ch, merged); ch.forEach { it.release() }
        Imgproc.cvtColor(merged, img, Imgproc.COLOR_YCrCb2BGR); merged.release()

        // 7) Vibrance
        val hsv = Mat(); Imgproc.cvtColor(img, hsv, Imgproc.COLOR_BGR2HSV)
        val hc = ArrayList<Mat>(); Core.split(hsv, hc)
        hc[1].convertTo(hc[1], -1, 1.12, 0.0)
        Core.merge(hc, hsv); hc.forEach { it.release() }
        Imgproc.cvtColor(hsv, img, Imgproc.COLOR_HSV2BGR); hsv.release()

        val rgba = Mat(); Imgproc.cvtColor(img, rgba, Imgproc.COLOR_BGR2RGBA)
        val bmp = Bitmap.createBitmap(rgba.cols(), rgba.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgba, bmp); rgba.release(); img.release()
        return bmp
    }

    private fun unsharp(m: Mat, amount: Double, sigma: Double) {
        val b = Mat(); Imgproc.GaussianBlur(m, b, Size(0.0, 0.0), sigma)
        Core.addWeighted(m, 1 + amount, b, -amount, 0.0, m); b.release()
    }

    private fun dehaze(img: Mat, amount: Double) {
        val small = Mat(); Imgproc.resize(img, small, Size(), 0.25, 0.25, Imgproc.INTER_AREA)
        val c = ArrayList<Mat>(); Core.split(small, c); small.release()
        val dark = Mat(); Core.min(c[0], c[1], dark); Core.min(dark, c[2], dark); c.forEach { it.release() }
        Imgproc.erode(dark, dark, Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(9.0, 9.0)))
        if (Core.mean(dark).`val`[0] < 50.0) { dark.release(); return } // clear scene: skip
        val a = Core.minMaxLoc(dark).maxVal.coerceIn(180.0, 245.0)
        val t = Mat(); dark.convertTo(t, CvType.CV_32F, -amount / a, 1.0); dark.release()
        Core.max(t, Scalar(0.3), t)
        val tf = Mat(); Imgproc.resize(t, tf, img.size(), 0.0, 0.0, Imgproc.INTER_LINEAR); t.release()
        Imgproc.GaussianBlur(tf, tf, Size(0.0, 0.0), 8.0)
        val t3 = Mat(); Imgproc.cvtColor(tf, t3, Imgproc.COLOR_GRAY2BGR); tf.release()
        val f = Mat(); img.convertTo(f, CvType.CV_32FC3)
        val A = Scalar(a, a, a)
        Core.subtract(f, A, f); Core.divide(f, t3, f); Core.add(f, A, f)
        f.convertTo(img, CvType.CV_8UC3); f.release(); t3.release()
    }

    fun save(ctx: Context, bmp: Bitmap): Boolean {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "PROCAM_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ProCam")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return false
        ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 98, it) }
        return true
    }
}
